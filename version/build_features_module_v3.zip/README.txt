preprocess_features.py
1) Put next to your 'work' folder or run from anywhere.
2) Run: python preprocess_features.py --work .\work
Outputs: work\features_users_clean.csv and work\features_hosts_clean.csv
Purpose: convert feature columns to numeric and replace NaN with 0.
